import networkx as nx
import copy
import random as rd
import os
import uuid

class PhysicalGraphGenerator:
    def __init__(self, nodecap: int | tuple[int, int, int], linkcap: int | tuple[int, int, int]):
        pass

    def Generate(self,) -> nx.DiGraph:
        pass

    def Seed(x=None):
        rd.seed(x)