import networkx as nx
import random as rd
import uuid

class SfcGraphGenerator:
    def __init__(self,)->None:
        pass
    def Generate(self,)->nx.DiGraph:
        pass
    def Seed(x=None)->None:
        rd.seed(x)