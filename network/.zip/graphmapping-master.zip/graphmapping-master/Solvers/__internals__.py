import sys
import os

sys.path.append(os.path.dirname(__file__))
from GraphMappingProblem import GraphMappingProblem

class GraphMappingSolver:
    def __init__(self, problem: GraphMappingProblem, logpath:str=None, timelimit:int=None, verbose:bool=False):
        pass

    def Solve(self,) -> GraphMappingProblem:
        pass

